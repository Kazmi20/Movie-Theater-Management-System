package moviegui;
public class MovieSeats {

    int seatNumber;
    
    
    MovieSeats(int seatNumber){
        
        this.seatNumber = seatNumber;
    }

   

    public int getSeatNumber() {
        return seatNumber;
    }

   

    public void setSeatNumber(int seatNumber) {
        this.seatNumber = seatNumber;
    }



    
}
