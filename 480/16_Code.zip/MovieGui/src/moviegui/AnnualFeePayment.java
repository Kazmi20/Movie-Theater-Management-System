package moviegui;
public class AnnualFeePayment implements MoneyPayment {
    @Override
    public double calcPayment(){
        return 20;
        
    }

    
}
