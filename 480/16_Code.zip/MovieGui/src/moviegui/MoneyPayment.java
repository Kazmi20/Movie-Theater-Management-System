package moviegui;
public interface MoneyPayment {

    abstract double calcPayment();

    
}
